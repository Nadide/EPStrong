package com.example.epstrong;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SubInfo1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_info1);
    }
}
